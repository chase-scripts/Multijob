-- =============================================
--        Server Main - server/main.lua
-- =============================================

local Core      = nil
local Players   = {}   -- cache: { [src] = { jobs = {}, activeJob = nil } }

-- ── Framework Init ──────────────────────────────────────────────────────────

CreateThread(function()
    Wait(500)
    if Framework.Name == 'qbox' then
        Core = exports.qbx_core:GetCoreObject()
    elseif Framework.Name == 'qbcore' then
        Core = exports['qb-core']:GetCoreObject()
    elseif Framework.Name == 'esx' then
        Core = exports['es_extended']:getSharedObject()
    end
    if Config.Debug then
        print('^2[MultiJob] Server framework loaded: ' .. tostring(Framework.Name) .. '^7')
    end
end)

-- ── Internal Helpers ─────────────────────────────────────────────────────────

local function Log(msg)
    if Config.Debug then
        print('^3[MultiJob] ' .. msg .. '^7')
    end
end

local function GetPlayerData(src)
    if Framework.Name == 'qbox' then
        return exports.qbx_core:GetPlayer(src)
    elseif Framework.Name == 'qbcore' then
        return Core.Functions.GetPlayer(src)
    elseif Framework.Name == 'esx' then
        return Core.GetPlayerFromId(src)
    end
end

local function GetJobList()
    if Framework.Name == 'qbox' or Framework.Name == 'qbcore' then
        return Core.Shared.Jobs or {}
    elseif Framework.Name == 'esx' then
        -- ESX stores jobs differently; return a basic table
        local jobs = {}
        local dbJobs = MySQL and MySQL.query.await('SELECT name, label FROM jobs') or {}
        for _, v in ipairs(dbJobs) do
            jobs[v.name] = { label = v.label }
        end
        return jobs
    end
    return {}
end

local function GetJobLabel(jobName)
    local jobs = GetJobList()
    if jobs[jobName] then
        return jobs[jobName].label or jobName
    end
    return jobName
end

-- Ensure player entry exists in cache
local function EnsurePlayer(src)
    if not Players[src] then
        Players[src] = { jobs = {}, activeJob = nil }
    end
end

-- ── Apply Job to Framework ────────────────────────────────────────────────────

local function ApplyJobToFramework(src, jobName, grade)
    grade = grade or 0
    local player = GetPlayerData(src)
    if not player then return end

    if Framework.Name == 'qbox' or Framework.Name == 'qbcore' then
        player.Functions.SetJob(jobName, grade)
    elseif Framework.Name == 'esx' then
        player.setJob(jobName, grade)
    end
end

-- ── Server Callbacks ─────────────────────────────────────────────────────────

lib.callback.register('multijob:getPlayerJobs', function(src)
    EnsurePlayer(src)
    return Players[src].jobs
end)

lib.callback.register('multijob:getAllJobs', function(src)
    return GetJobList()
end)

-- ── Server Events ─────────────────────────────────────────────────────────────

-- Add a job to a player (called by other resources / admin scripts)
RegisterNetEvent('multijob:addJob', function(jobName, grade)
    local src = source
    EnsurePlayer(src)

    local jobs    = Players[src].jobs
    local count   = 0
    for _ in pairs(jobs) do count = count + 1 end

    if count >= Config.MaxJobs then
        TriggerClientEvent('multijob:notify', src,
            'You have reached the maximum number of jobs (' .. Config.MaxJobs .. ').', 'error')
        return
    end

    if jobs[jobName] then
        TriggerClientEvent('multijob:notify', src, 'You already have this job.', 'error')
        return
    end

    grade = grade or 0
    local label = GetJobLabel(jobName)

    jobs[jobName] = {
        label       = label,
        grade       = grade,
        grade_label = 'Grade ' .. grade,
        active      = (Players[src].activeJob == nil), -- first job auto-active
    }

    -- If this is the first job, set it active in the framework
    if Players[src].activeJob == nil then
        Players[src].activeJob = jobName
        ApplyJobToFramework(src, jobName, grade)
    end

    Log('Player ' .. src .. ' added job: ' .. jobName)
    TriggerClientEvent('multijob:notify', src, 'You have been hired as ' .. label .. '!', 'success')
end)

-- Remove a job from a player
RegisterNetEvent('multijob:removeJob', function(jobName)
    local src = source
    EnsurePlayer(src)

    local jobs = Players[src].jobs
    if not jobs[jobName] then
        TriggerClientEvent('multijob:notify', src, 'You do not have this job.', 'error')
        return
    end

    local wasActive = (Players[src].activeJob == jobName)
    jobs[jobName] = nil

    if wasActive then
        -- Find next available job to set active
        Players[src].activeJob = nil
        local nextJob, nextGrade = nil, 0
        for name, data in pairs(jobs) do
            nextJob   = name
            nextGrade = data.grade or 0
            data.active = true
            break
        end

        if nextJob then
            Players[src].activeJob = nextJob
            ApplyJobToFramework(src, nextJob, nextGrade)
        else
            -- No jobs left — set unemployed
            ApplyJobToFramework(src, 'unemployed', 0)
        end
    end

    Log('Player ' .. src .. ' removed job: ' .. jobName)
    TriggerClientEvent('multijob:notify', src,
        'You have been removed from ' .. GetJobLabel(jobName) .. '.', 'inform')
end)

-- Set a player's active job
RegisterNetEvent('multijob:setActiveJob', function(jobName)
    local src = source
    EnsurePlayer(src)

    local jobs = Players[src].jobs
    if not jobs[jobName] then
        TriggerClientEvent('multijob:notify', src, 'You do not have this job.', 'error')
        return
    end

    -- Deactivate all, activate selected
    for name, data in pairs(jobs) do
        data.active = (name == jobName)
    end

    Players[src].activeJob = jobName
    ApplyJobToFramework(src, jobName, jobs[jobName].grade or 0)

    Log('Player ' .. src .. ' set active job: ' .. jobName)
    TriggerClientEvent('multijob:notify', src,
        jobs[jobName].label .. ' is now your active job.', 'success')
end)

-- ── Exports (for other resources) ────────────────────────────────────────────

exports('GetPlayerJobs', function(src)
    EnsurePlayer(src)
    return Players[src].jobs
end)

exports('GetActiveJob', function(src)
    EnsurePlayer(src)
    return Players[src].activeJob
end)

exports('PlayerHasJob', function(src, jobName)
    EnsurePlayer(src)
    return Players[src].jobs[jobName] ~= nil
end)

exports('AddJobToPlayer', function(src, jobName, grade)
    TriggerEvent('multijob:addJob', jobName, grade)
end)

-- ── Cleanup on player disconnect ─────────────────────────────────────────────

AddEventHandler('playerDropped', function()
    local src = source
    Players[src] = nil
    Log('Cleaned up data for player ' .. src)
end)
