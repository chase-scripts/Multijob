# MultiJob Script
**Compatible with QBox · QBCore · ESX**

---

## 📁 File Structure

```
multijob/
├── fxmanifest.lua
├── config.lua
├── shared/
│   └── framework.lua
├── client/
│   └── main.lua
└── server/
    └── main.lua
```

---

## ⚙️ Installation

1. Drop the `multijob` folder into your `resources` directory.
2. Add `ensure multijob` to your `server.cfg`.
3. Make sure **ox_lib** is installed and started **before** this resource.
4. Edit `config.lua` to suit your server.

---

## 🛠️ Config Options

| Option | Default | Description |
|---|---|---|
| `Config.Framework` | `'auto'` | `'auto'`, `'qbox'`, `'qbcore'`, or `'esx'` |
| `Config.MaxJobs` | `3` | Max jobs a player can hold |
| `Config.UseActiveJob` | `true` | Allow setting an active job |
| `Config.NotifyStyle` | `'ox_lib'` | `'ox_lib'`, `'native'`, or `'framework'` |
| `Config.MenuCommand` | `'myjobs'` | Command to open the job menu |
| `Config.Debug` | `false` | Print debug logs to console |

---

## 📌 Commands

| Command | Description |
|---|---|
| `/myjobs` | Opens your personal job management menu |

---

## 📡 Server Events (trigger from other resources)

```lua
-- Add a job to a player
TriggerServerEvent('multijob:addJob', jobName, grade)

-- Remove a job from a player
TriggerServerEvent('multijob:removeJob', jobName)

-- Set a player's active job
TriggerServerEvent('multijob:setActiveJob', jobName)
```

---

## 📦 Server Exports (use in other server-side scripts)

```lua
-- Get all jobs a player has
local jobs = exports['multijob']:GetPlayerJobs(source)

-- Get the player's current active job name
local activeJob = exports['multijob']:GetActiveJob(source)

-- Check if a player has a specific job
local hasJob = exports['multijob']:PlayerHasJob(source, 'police')

-- Add a job to a player programmatically
exports['multijob']:AddJobToPlayer(source, 'mechanic', 1)
```

---

## 📋 Dependencies

- [ox_lib](https://github.com/overextended/ox_lib) *(required)*
- One of: **qbx_core**, **qb-core**, or **es_extended**
- oxmysql *(only needed for ESX job list fetching)*
