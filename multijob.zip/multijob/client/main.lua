-- =============================================
--        Client Main - client/main.lua
-- =============================================

local Core = nil

-- ── Framework Init ──────────────────────────────────────────────────────────

CreateThread(function()
    Wait(500)
    if Framework.Name == 'qbox' then
        Core = exports.qbx_core:GetCoreObject()
    elseif Framework.Name == 'qbcore' then
        Core = exports['qb-core']:GetCoreObject()
    elseif Framework.Name == 'esx' then
        Core = exports['es_extended']:getSharedObject()
    end
end)

-- ── Helpers ─────────────────────────────────────────────────────────────────

local function Notify(msg, msgType)
    msgType = msgType or 'inform'
    if Config.NotifyStyle == 'ox_lib' then
        lib.notify({
            title       = 'MultiJob',
            description = msg,
            type        = msgType,
            -- ox_lib supports a position option; colour theming via type mapping
        })
    elseif Config.NotifyStyle == 'native' then
        SetNotificationTextEntry('STRING')
        AddTextComponentString(msg)
        DrawNotification(false, true)
    else
        if Framework.Name == 'esx' then
            Core.ShowNotification(msg)
        else
            Core.Functions.Notify(msg, msgType)
        end
    end
end

local function GetPlayerJobs()
    local p = promise.new()
    TriggerServerCallback('multijob:getPlayerJobs', function(jobs)
        p:resolve(jobs)
    end)
    return Citizen.Await(p)
end

-- ── Job Menu ─────────────────────────────────────────────────────────────────
-- The accent colour from Config.ActiveColor is injected into the menu title
-- and item icons so the UI reflects whatever theme the server has chosen.

local function OpenJobMenu()
    local playerJobs = GetPlayerJobs()
    local options    = {}

    if next(playerJobs) then
        for jobName, jobData in pairs(playerJobs) do
            local isActive = jobData.active
            options[#options + 1] = {
                title       = '📋 ' .. (jobData.label or jobName),
                description = 'Grade: ' .. (jobData.grade_label or 'N/A') .. (isActive and '  ✅ Active' or ''),
                colorScheme = isActive and 'green' or nil,
                onSelect    = function()
                    OpenJobActions(jobName, jobData, isActive)
                end
            }
        end
    else
        options[#options + 1] = {
            title       = 'No Jobs',
            description = 'You currently have no jobs assigned.',
            disabled    = true
        }
    end

    options[#options + 1] = { title = '────────────────', disabled = true }

    local count = 0
    for _ in pairs(playerJobs) do count = count + 1 end
    options[#options + 1] = {
        title    = '📊 Job Slots: ' .. count .. ' / ' .. Config.MaxJobs,
        disabled = true
    }

    lib.registerContext({
        id      = 'multijob_menu',
        title   = '🏢 My Jobs',
        options = options,
    })
    lib.showContext('multijob_menu')
end

function OpenJobActions(jobName, jobData, isActive)
    local options = {}

    if Config.UseActiveJob then
        if not isActive then
            options[#options + 1] = {
                title       = '✅ Set as Active Job',
                description = 'Set this as your currently active job',
                onSelect    = function()
                    TriggerServerEvent('multijob:setActiveJob', jobName)
                end
            }
        else
            options[#options + 1] = {
                title       = '✅ Currently Active',
                description = 'This is already your active job',
                disabled    = true
            }
        end
    end

    options[#options + 1] = {
        title       = '❌ Quit Job',
        description = 'Remove yourself from this job',
        onSelect    = function()
            lib.alertDialog({
                header  = 'Quit Job?',
                content = 'Are you sure you want to quit **' .. (jobData.label or jobName) .. '**?',
                centered = true,
                cancel  = true
            }, function(confirmed)
                if confirmed == 'confirm' then
                    TriggerServerEvent('multijob:removeJob', jobName)
                end
            end)
        end
    }

    lib.registerContext({
        id      = 'multijob_actions',
        title   = '⚙️ ' .. (jobData.label or jobName),
        menu    = 'multijob_menu',
        options = options,
    })
    lib.showContext('multijob_actions')
end

-- ── Command ───────────────────────────────────────────────────────────────────

RegisterCommand(Config.MenuCommand, function()
    OpenJobMenu()
end, false)

-- ── Events (from server) ──────────────────────────────────────────────────────

RegisterNetEvent('multijob:notify', function(msg, msgType)
    Notify(msg, msgType)
end)

RegisterNetEvent('multijob:refreshMenu', function()
    -- Optionally re-open menu after server changes
end)
