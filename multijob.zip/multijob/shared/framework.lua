-- =============================================
--    Framework Bridge - shared/framework.lua
-- =============================================

Framework = {}
Framework.Name = nil

local function detectFramework()
    if Config.Framework ~= 'auto' then
        Framework.Name = Config.Framework
        return
    end

    if GetResourceState('qbx_core') == 'started' then
        Framework.Name = 'qbox'
    elseif GetResourceState('qb-core') == 'started' then
        Framework.Name = 'qbcore'
    elseif GetResourceState('es_extended') == 'started' then
        Framework.Name = 'esx'
    else
        print('^1[MultiJob] ERROR: No supported framework detected!^7')
    end
end

detectFramework()

if Config.Debug then
    print('^3[MultiJob] Framework detected: ' .. tostring(Framework.Name) .. '^7')
end
