-- =============================================
--        MultiJob Config - config.lua
-- =============================================

Config = {}

-- ┌─────────────────────────────────────────────────────────────────────────┐
-- │  FRAMEWORK                                                              │
-- └─────────────────────────────────────────────────────────────────────────┘
-- Options: 'auto' | 'qbox' | 'qbcore' | 'esx'
Config.Framework = 'auto'

-- ┌─────────────────────────────────────────────────────────────────────────┐
-- │  JOB SETTINGS                                                           │
-- └─────────────────────────────────────────────────────────────────────────┘
Config.MaxJobs      = 3
Config.UseActiveJob = true
Config.MenuCommand  = 'myjobs'

-- ┌─────────────────────────────────────────────────────────────────────────┐
-- │  NOTIFICATIONS                                                          │
-- └─────────────────────────────────────────────────────────────────────────┘
-- Options: 'ox_lib' | 'native' | 'framework'
Config.NotifyStyle = 'ox_lib'

-- ┌─────────────────────────────────────────────────────────────────────────┐
-- │  COLOUR THEME                                                           │
-- └─────────────────────────────────────────────────────────────────────────┘
--
-- Set Config.Theme to one of the preset names below, or provide your own
-- hex colour in Config.CustomColor (this will override the preset).
--
--  Preset Name │ Description           │ Hex
-- ─────────────┼───────────────────────┼──────────
--  'blue'      │ Classic police-blue   │ #3B82F6
--  'green'     │ Military / nature     │ #22C55E
--  'red'       │ Fire / danger         │ #EF4444
--  'orange'    │ Construction / warm   │ #F97316
--  'yellow'    │ Taxi / caution        │ #EAB308
--  'cyan'      │ Tech / medical        │ #06B6D4
--  'purple'    │ VIP / luxury          │ #A855F7
--  'pink'      │ Entertainment         │ #EC4899
--  'white'     │ Clean / minimal       │ #F1F5F9
--  'gold'      │ Premium / elite       │ #D97706

Config.Theme = 'blue'

-- Set to a hex string to override the preset. e.g. '#00FFB3'
-- Set to nil to use the preset above.
Config.CustomColor = nil

-- Preset colour map — tweak hex values here to adjust a preset.
Config.ThemeColors = {
    blue   = '#3B82F6',
    green  = '#22C55E',
    red    = '#EF4444',
    orange = '#F97316',
    yellow = '#EAB308',
    cyan   = '#06B6D4',
    purple = '#A855F7',
    pink   = '#EC4899',
    white  = '#F1F5F9',
    gold   = '#D97706',
}

-- Resolved active colour (do not edit this line).
Config.ActiveColor = Config.CustomColor or Config.ThemeColors[Config.Theme] or '#3B82F6'

-- ┌─────────────────────────────────────────────────────────────────────────┐
-- │  DEBUG                                                                  │
-- └─────────────────────────────────────────────────────────────────────────┘
Config.Debug = false
