fx_version 'cerulean'
game 'gta5'

author 'MultiJob Script'
description 'Multi-Job System - Compatible with QBox, QBCore & ESX'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
    'shared/framework.lua',
}

client_scripts {
    'client/main.lua',
}

server_scripts {
    'server/main.lua',
}

lua54 'yes'
